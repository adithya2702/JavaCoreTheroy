public class PrintStatements {
    public static void main(String[] args) {
        //print
        System.out.print("Hello");
        System.out.print("World");
        //println
        System.out.println("Hello");
        System.out.println("World!");
        //printf
        System.out.printf("The year is %d and month is %s",2024,"June");

        //if we want to print in red colour like error
        System.err.print("There is no error");
        System.err.println("There is no error");
        System.err.printf("There is no %s","Money");
    }
}
/*

%b      boolean
%c      char
%d      integer
%e      scientificNotation
%f      float
%s      string
%tc     complete date and time
%n      a newline
%%      the character %

*/
