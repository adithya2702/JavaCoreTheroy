package OOPS.Inhertance;
//here we can do multiple inheritance
public interface interfaceUser extends interfaceAdmin,interfaceDeveloper {
    public static void main(String[] args) {

    }
}
