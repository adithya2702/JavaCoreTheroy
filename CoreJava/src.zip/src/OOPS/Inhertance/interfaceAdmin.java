package OOPS.Inhertance;

public interface interfaceAdmin {
    public void read();
}
