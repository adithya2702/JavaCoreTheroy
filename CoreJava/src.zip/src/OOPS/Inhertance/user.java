package OOPS.Inhertance;

public class user extends developer {
    public static void main(String[] args) {
        read();
        write();
    }
}
