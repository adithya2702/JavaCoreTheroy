package OOPS.Inhertance;

//Inheritance is mechanism in which one class acquires properties and behaviour(means methods and variables) of another class
/*
    Multiple Inheritance(father,mother,aunt,uncle)  //In class level we cannot do this in java but can to interface level.
    Multi-level(son-father-grandfather..)
 */
public class admin {
    public static void read(){
        System.out.println("parent say hii");
    }

}
