package OOPS.Inhertance;

public interface interfaceDeveloper extends interfaceAdmin  {
    public void write();
}
