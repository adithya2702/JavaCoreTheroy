package OOPS.InterfaceAbstraction;

public class audi implements carFunctionalInterface {

    @Override
    public void drive() {
        System.out.println("Drive this car");
    }
}
