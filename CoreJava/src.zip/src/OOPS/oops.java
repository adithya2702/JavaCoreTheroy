package OOPS;//Object-Oriented Programming System(OOPS) is a paradigm(approach to solve a problem) in which all are int he from of object.
/*Principles of OOPS
    1.Inheritance //check code re-usability
    2.Encapsulation //tablet capsule and class is example
    3.Polymorphism //same method have different behaviours
    4.Abstraction //hide some info
 */
//Object-Oriented is different from Object Based here we don't have Inhertance.inheritance
//Java is not pure OOP language because of primitive data types these are in the form of objects.
//Examples of OOP languages are JAVA,PYTHON,C++,C#(C shark).
//Simula is first OOP language
//Smalltalk is 100% OOP language

public class oops {
}
