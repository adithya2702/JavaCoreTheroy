/*
5 types
1. Arithmetic       +,-,*,/,%
2. Unary            ++,--           we can use pre and post for this operator
3. Relational       ==,!=,>,<,>=,<=
4. Conditional      &&,||
5. Assignment       =,+=,-=,*=,/=,%=
 */

public class Operators {
    public static void main(String[] args) {
        int x=20;
        int y=10;
        System.out.println(x+y);
        System.out.println(x-y);
        System.out.println(x*y);
        System.out.println(x/y);
        System.out.println(x%y);

        System.out.println(x);//20
        System.out.println(++x);//21
        System.out.println(x++);//21
        System.out.println(x);

        System.out.println(x+=5);// x=x+5
        System.out.println(x%=5);// x=x%5 remainder

        int i=0;
        int k= i++ + ++i + i-- - --i;
        System.out.println(k);
    }
}
