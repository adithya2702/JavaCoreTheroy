public class Methods {
    static int currentBalance = 1000;
    public static void deposit(int amount){
        currentBalance = currentBalance+amount;
        System.out.println(currentBalance);
    }
    public  void withdraw(int amount){
        currentBalance = currentBalance- amount;
        System.out.println(currentBalance);
    }
    public int getBalance(){
        return currentBalance;
    }
    public static void main(String[] args) {
        System.out.println(currentBalance);
        deposit(200);
        //withdraw is not static so create object
        Methods m= new Methods();
        m.withdraw(500);
        m.getBalance();
    }
}
