public class Variables {
    int id= 100; //Instacnce Variables
    static String Name = "Adi"; // Class Variables
    public static void main(String[] args) {
        String firstName= "Padavala"; // Local variables
        System.out.println(Name);
     // System.out.println(id); // because it is nonstatic we should create object to call
        Variables var= new Variables();
        System.out.println(var.id);
    }
    public void method(int id2 /*Parameters: we cannot assign values here*/){
        id2=200;
        System.out.println(id2);
      // System.out.println(firstName); // we cant call local variables to other methods

        //Rules
        double MATH_PIE = 3.14; // universal constants must be capital
        String lastName = "Adithya"; // no shortcuts as LN
      //int class= 20;  //No  keywords for variables
        // we can use '_' '$' are two special characters in variables
    }
}

