/**
 * Documentation comments used to say about the class object full data like websites information
 * It is used above package,class,variables but not inside methods
 * @author Adithya thie is author tag
 * @version 1.1 this is version tag
 *
 *
 */
public class Comments {
    //Single line comment
    /*
    multi line comments
     */
    /**
     * @parameter here a is a parameter
     */
    int a = 20;
    public static void main(String[] args) {
        Comments c = new Comments();
    }
}
