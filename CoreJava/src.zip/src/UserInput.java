import java.util.Scanner;
public class UserInput {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("What is your name?");
        String name= sc.nextLine();
        System.out.printf("Hello %s, How are you? \n",name);
        String status = sc.nextLine();
        System.out.println("What is your age?");
        int age = sc.nextInt();
        System.out.println(name +" is "+age+" years old.");
        sc.close();
    }
}
